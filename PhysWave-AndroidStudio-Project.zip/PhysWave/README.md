# PHYSWAVE – Media Pembelajaran Fisika Interaktif
Kotlin + Jetpack Compose • minSdk 26 (Android 8.0) • targetSdk 34

## Struktur folder
```
PhysWave/
├── build.gradle.kts            settings.gradle.kts     gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/ (values, drawable, mipmap-anydpi-v26)
        └── java/com/physwave/app/
            ├── MainActivity.kt
            ├── data/  Materi.kt  Soal.kt  Lainnya.kt (video, praktikum, LKPD, rangkuman)  Store.kt
            └── ui/    Nav.kt  Common.kt  Screens1.kt (splash, beranda, materi, video, simulasi)
                       Screens2.kt (praktikum, LKPD)  Sensor.kt (accelerometer, mikrofon)
                       Screens3.kt (analisis data, latihan, kuis, evaluasi, rangkuman, tentang)
```

## 1. Membuka project
1. Pasang Android Studio versi terbaru (Koala / Ladybug atau lebih baru) dan koneksi internet (untuk mengunduh Gradle & library).
2. File > Open > pilih folder `PhysWave` (folder yang berisi `settings.gradle.kts`).
3. Tunggu "Gradle Sync" selesai. Jika diminta, izinkan Android Studio mengunduh Gradle 8.7 dan Android SDK 34.
   (File `gradle-wrapper.jar` tidak disertakan; Android Studio akan menanganinya otomatis.)

## 2. Menjalankan aplikasi
Pilih perangkat di toolbar (emulator atau HP) lalu klik tombol Run ▶.

## 3. Menghubungkan HP Android
1. HP: Pengaturan > Tentang ponsel > ketuk "Nomor build" 7 kali untuk mengaktifkan Opsi Pengembang.
2. Pengaturan > Opsi pengembang > aktifkan "Debugging USB".
3. Sambungkan HP ke komputer dengan kabel USB, izinkan "Allow USB debugging".
4. Nama HP akan muncul di daftar perangkat Android Studio.
Catatan: sensor accelerometer dan mikrofon sebaiknya diuji di HP sungguhan, bukan emulator.

## 4. Build APK debug
Build > Build Bundle(s) / APK(s) > Build APK(s).
Hasil: `app/build/outputs/apk/debug/app-debug.apk`

## 5. Build APK release
Cara cepat (siap dipasang untuk uji coba, memakai kunci debug):
`Build > Select Build Variant` → pilih `release`, lalu Build > Build APK(s), atau di Terminal:
`./gradlew assembleRelease` (Windows: `gradlew.bat assembleRelease`)
Hasil: `app/build/outputs/apk/release/app-release.apk`

Untuk dibagikan resmi / Play Store, buat keystore sendiri:
Build > Generate Signed Bundle / APK > APK > Create new… > isi data keystore > pilih `release` > Create.
Simpan file keystore dan password Anda baik-baik.

## 6. Meng-install APK di HP
1. Salin file APK ke HP (kabel USB, WhatsApp, Google Drive, dll).
2. Buka file APK di HP. Jika diminta, izinkan "Install dari sumber ini".
3. Ketuk Install lalu buka PHYSWAVE.
Alternatif dengan kabel: `adb install -r app-debug.apk`

## Mengganti URL video
Ubah nilai `url` pada `daftarVideo` di `data/Lainnya.kt`, atau di aplikasi tekan tombol "Ubah URL" pada kartu video.
