package com.physwave.app.ui

import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.physwave.app.data.Store
import java.util.Locale
import kotlin.math.sin

val Blue900 = Color(0xFF0D47A1)
val Blue700 = Color(0xFF1565C0)
val Blue500 = Color(0xFF2196F3)
val Blue100 = Color(0xFFBBDEFB)
val Blue50 = Color(0xFFE3F2FD)
val BgColor = Color(0xFFF4F8FE)
val GreenOk = Color(0xFF2E7D32)
val RedBad = Color(0xFFC62828)
val TextDark = Color(0xFF263238)
const val TWO_PI = 6.2831855f

@Composable
fun PhysWaveTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue700, onPrimary = Color.White,
            primaryContainer = Blue50, onPrimaryContainer = Blue900,
            secondary = Blue500, background = BgColor, surface = Color.White,
            surfaceVariant = Blue50
        ),
        content = content
    )
}

// ---------- helper angka ----------
fun fmt(v: Double, d: Int = 2): String {
    if (v.isNaN() || v.isInfinite()) return "-"
    val s = String.format(Locale.US, "%." + d + "f", v)
    return if (s.contains('.')) s.trimEnd('0').trimEnd('.') else s
}

fun parseNum(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()

private fun fmtTick(v: Float, range: Float): String {
    val d = when {
        range >= 100f -> 0
        range >= 10f -> 1
        range >= 1f -> 2
        range >= 0.1f -> 3
        else -> 4
    }
    return fmt(v.toDouble(), d)
}

// ---------- layout dasar ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PwScreen(
    title: String,
    nav: NavController,
    scroll: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Scaffold(
        containerColor = BgColor,
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold, maxLines = 1) },
                navigationIcon = {
                    TextButton(onClick = { nav.popBackStack() }) {
                        Text("←", color = Color.White, fontSize = 26.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Blue700, titleContentColor = Color.White
                )
            )
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .then(if (scroll) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
fun PwCard(
    modifier: Modifier = Modifier,
    container: Color = Color.White,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
fun Heading(text: String) =
    Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Blue900)

@Composable
fun Label(text: String) =
    Text(text.uppercase(), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Blue500)

@Composable
fun Body(text: String, color: Color = TextDark) =
    Text(text, fontSize = 14.sp, lineHeight = 21.sp, color = color)

@Composable
fun PwButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    color: Color = Blue700,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color)
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun SavedField(key: String, label: String, minLines: Int = 2) {
    var text by remember(key) { mutableStateOf(Store.getText(key)) }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it; Store.putText(key, it) },
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        minLines = minLines
    )
}

// ---------- grafik ----------
@Composable
fun PlotChart(
    title: String,
    xLabel: String,
    yLabel: String,
    xs: List<Float>,
    ys: List<Float>,
    asLine: Boolean,
    modifier: Modifier = Modifier,
    height: Dp = 230.dp
) {
    val paint = remember { Paint().apply { isAntiAlias = true; color = 0xFF37474F.toInt() } }
    Column(modifier.fillMaxWidth()) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Blue900)
        Spacer(Modifier.height(4.dp))
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(height)
                .background(Color.White, RoundedCornerShape(8.dp))
        ) {
            val nc = drawContext.canvas.nativeCanvas
            paint.textSize = 10.sp.toPx()
            val ml = 52.dp.toPx(); val mb = 40.dp.toPx()
            val mt = 10.dp.toPx(); val mr = 14.dp.toPx()
            val pw = size.width - ml - mr
            val ph = size.height - mt - mb
            val n = minOf(xs.size, ys.size)
            if (n == 0) {
                paint.textAlign = Paint.Align.CENTER
                nc.drawText("Belum ada data", size.width / 2, size.height / 2, paint)
                return@Canvas
            }
            val xv = xs.take(n); val yv = ys.take(n)
            val xmin = xv.minOrNull() ?: 0f; val xmax = xv.maxOrNull() ?: 1f
            val ymin = yv.minOrNull() ?: 0f; val ymax = yv.maxOrNull() ?: 1f
            var x0 = if (xmin >= 0f) 0f else xmin
            var x1 = xmax
            if (x1 <= x0) x1 = x0 + 1f
            x1 += (x1 - x0) * 0.05f
            var y0 = if (ymin >= 0f) 0f else ymin - 0.05f * (ymax - ymin)
            var y1 = ymax
            if (y1 <= y0) y1 = y0 + 1f
            y1 += (y1 - y0) * 0.08f
            val px = { x: Float -> ml + (x - x0) / (x1 - x0) * pw }
            val py = { y: Float -> mt + ph - (y - y0) / (y1 - y0) * ph }

            for (i in 0..4) {
                val gx = x0 + (x1 - x0) * i / 4f
                val gy = y0 + (y1 - y0) * i / 4f
                drawLine(Color(0xFFE0E0E0), Offset(px(gx), mt), Offset(px(gx), mt + ph), 1f)
                drawLine(Color(0xFFE0E0E0), Offset(ml, py(gy)), Offset(ml + pw, py(gy)), 1f)
                paint.textAlign = Paint.Align.CENTER
                nc.drawText(fmtTick(gx, x1 - x0), px(gx), mt + ph + 14.dp.toPx(), paint)
                paint.textAlign = Paint.Align.RIGHT
                nc.drawText(fmtTick(gy, y1 - y0), ml - 5.dp.toPx(), py(gy) + 3.dp.toPx(), paint)
            }
            drawLine(Color.DarkGray, Offset(ml, mt), Offset(ml, mt + ph), 2f)
            drawLine(Color.DarkGray, Offset(ml, mt + ph), Offset(ml + pw, mt + ph), 2f)

            if (asLine && n > 1) {
                val path = Path()
                for (i in 0 until n) {
                    if (i == 0) path.moveTo(px(xv[i]), py(yv[i])) else path.lineTo(px(xv[i]), py(yv[i]))
                }
                drawPath(path, Blue500, style = Stroke(width = 2.5.dp.toPx()))
            }
            if (n <= 60) {
                for (i in 0 until n) {
                    drawCircle(Blue700, 4.5.dp.toPx(), Offset(px(xv[i]), py(yv[i])))
                }
            }
            paint.textAlign = Paint.Align.CENTER
            nc.drawText(xLabel, ml + pw / 2, size.height - 5.dp.toPx(), paint)
            nc.save()
            nc.rotate(-90f, 12.dp.toPx(), mt + ph / 2)
            nc.drawText(yLabel, 12.dp.toPx(), mt + ph / 2, paint)
            nc.restore()
        }
    }
}

// ---------- ilustrasi sederhana ----------
private fun DrawScope.txt(
    s: String, x: Float, y: Float, size: Float,
    color: Int = 0xFF0D47A1.toInt(), align: Paint.Align = Paint.Align.CENTER
) {
    val p = Paint().apply {
        isAntiAlias = true
        textSize = size
        this.color = color
        textAlign = align
        isFakeBoldText = true
    }
    drawContext.canvas.nativeCanvas.drawText(s, x, y, p)
}

private fun sinePath(x0: Float, w: Float, cy: Float, amp: Float, cycles: Float): Path {
    val p = Path()
    val n = 120
    for (i in 0..n) {
        val x = x0 + w * i / n
        val y = cy - amp * sin(TWO_PI * cycles * i / n)
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    return p
}

@Composable
fun Illustration(kind: String, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(Blue50, RoundedCornerShape(12.dp))
    ) {
        val w = size.width; val h = size.height; val cy = h / 2
        val ts = 12.sp.toPx()
        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
        val stroke = Stroke(width = 4.dp.toPx())
        val x0 = 24f; val ww = w - 48f
        when (kind) {
            "longitudinal" -> {
                val amp = h * 0.28f
                val d = ww * 0.06f
                for (i in 0..40) {
                    val base = x0 + ww * i / 40f
                    val x = base - d * sin(TWO_PI * 2f * i / 40f)
                    drawLine(Blue700, Offset(x, cy - amp), Offset(x, cy + amp), 4f)
                }
                txt("rapatan", x0 + ww / 2, h - 10f, ts)
                txt("renggangan", x0 + ww / 4, h - 10f, ts)
                txt("arah rambat →", w / 2, 20f, ts)
            }
            "reflect" -> {
                val my = h * 0.8f
                drawLine(Color.DarkGray, Offset(w * 0.15f, my), Offset(w * 0.85f, my), 8f)
                drawLine(Color.Gray, Offset(w / 2, h * 0.1f), Offset(w / 2, my), 2f, pathEffect = dash)
                drawLine(Blue700, Offset(w * 0.2f, h * 0.15f), Offset(w / 2, my), 5f)
                drawLine(Color(0xFFE53935), Offset(w / 2, my), Offset(w * 0.8f, h * 0.15f), 5f)
                txt("datang", w * 0.22f, h * 0.1f, ts)
                txt("pantul", w * 0.78f, h * 0.1f, ts, 0xFFE53935.toInt())
                txt("normal", w / 2 + 34f, h * 0.2f, ts, 0xFF616161.toInt())
                txt("θi = θr", w / 2, h - 6f, ts)
            }
            "refract" -> {
                drawRect(Blue100, Offset(0f, cy), Size(w, h / 2))
                drawLine(Color.DarkGray, Offset(0f, cy), Offset(w, cy), 3f)
                drawLine(Color.Gray, Offset(w / 2, 0f), Offset(w / 2, h), 2f, pathEffect = dash)
                drawLine(Blue700, Offset(w * 0.15f, h * 0.05f), Offset(w / 2, cy), 5f)
                drawLine(Color(0xFFE53935), Offset(w / 2, cy), Offset(w * 0.62f, h * 0.97f), 5f)
                txt("medium 1 (lebih cepat)", w * 0.22f, cy - 8f, ts)
                txt("medium 2 (lebih lambat)", w * 0.25f, h - 8f, ts)
            }
            "diffract" -> {
                val bx = w * 0.4f
                drawRect(Color.DarkGray, Offset(bx - 6f, 0f), Size(12f, cy - 14f))
                drawRect(Color.DarkGray, Offset(bx - 6f, cy + 14f), Size(12f, h - cy - 14f))
                for (i in 1..3) {
                    val x = w * 0.08f * i
                    drawLine(Blue500, Offset(x, 10f), Offset(x, h - 10f), 4f)
                }
                for (i in 1..3) {
                    val r = 34f * i
                    drawArc(
                        Blue700, -70f, 140f, false,
                        Offset(bx - r, cy - r), Size(2 * r, 2 * r), style = Stroke(4f)
                    )
                }
                txt("celah", bx, h - 4f, ts)
            }
            "interf" -> {
                val a = Offset(w * 0.3f, cy - 26f); val b = Offset(w * 0.3f, cy + 26f)
                for (i in 1..7) {
                    drawCircle(Blue500.copy(alpha = 0.7f), 22f * i, a, style = Stroke(2f))
                    drawCircle(Color(0xFF00897B).copy(alpha = 0.7f), 22f * i, b, style = Stroke(2f))
                }
                drawCircle(Blue900, 6f, a); drawCircle(Blue900, 6f, b)
                txt("S1", a.x - 18f, a.y + 4f, ts); txt("S2", b.x - 18f, b.y + 4f, ts)
            }
            "polar" -> {
                drawRect(Color(0xFFB0BEC5), Offset(w * 0.42f, h * 0.08f), Size(w * 0.16f, h * 0.84f))
                drawRect(Color.White, Offset(w * 0.495f, h * 0.08f), Size(w * 0.01f, h * 0.84f))
                txt("↕ ↔ ⤢", w * 0.2f, cy + 10f, 30f)
                txt("↕", w * 0.8f, cy + 12f, 38f)
                txt("semua arah", w * 0.2f, h - 8f, ts)
                txt("terpolarisasi", w * 0.8f, h - 8f, ts)
            }
            else -> {
                val amp = h * 0.26f
                drawLine(Color.Gray, Offset(x0, cy), Offset(x0 + ww, cy), 2f, pathEffect = dash)
                drawPath(sinePath(x0, ww, cy, amp, 2f), Blue500, style = stroke)
                val crest1 = x0 + ww * 0.125f
                val crest2 = x0 + ww * 0.625f
                val trough1 = x0 + ww * 0.375f
                when (kind) {
                    "amplitudo" -> {
                        drawLine(Color(0xFFE53935), Offset(crest1, cy), Offset(crest1, cy - amp), 4f)
                        drawLine(Color(0xFFE53935), Offset(trough1, cy), Offset(trough1, cy + amp), 4f)
                        txt("A", crest1 + 14f, cy - amp / 2, ts + 2f, 0xFFE53935.toInt())
                        txt("A", trough1 + 14f, cy + amp / 2, ts + 2f, 0xFFE53935.toInt())
                        txt("puncak (bukit)", crest1 + 60f, cy - amp - 6f, ts)
                        txt("dasar (lembah)", trough1 + 60f, cy + amp + 16f, ts)
                    }
                    "period", "speed" -> {
                        val ly = cy - amp - 14f
                        drawLine(Color(0xFFE53935), Offset(crest1, ly), Offset(crest2, ly), 4f)
                        drawLine(Color(0xFFE53935), Offset(crest1, ly - 8f), Offset(crest1, ly + 8f), 4f)
                        drawLine(Color(0xFFE53935), Offset(crest2, ly - 8f), Offset(crest2, ly + 8f), 4f)
                        txt("λ", (crest1 + crest2) / 2, ly - 8f, ts + 4f, 0xFFE53935.toInt())
                        val bottom = if (kind == "speed") "v = λ × f   (→ arah rambat)" else "1 gelombang = 1 periode (T)   f = 1/T"
                        txt(bottom, w / 2, h - 8f, ts)
                    }
                    "apps" -> {
                        txt("📡   🔊   🩻   📶   🕶️", w / 2, 30f, 22.sp.toPx())
                    }
                    else -> {
                        txt("bukit", crest1, cy - amp - 8f, ts)
                        txt("lembah", trough1, cy + amp + 18f, ts)
                        txt("arah getar ↕", x0 + 50f, 18f, ts)
                        txt("arah rambat →", w - 80f, 18f, ts)
                    }
                }
            }
        }
    }
}
