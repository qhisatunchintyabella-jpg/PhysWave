package com.physwave.app.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") { SplashScreen(nav) }
        composable("home") { HomeScreen(nav) }
        composable("tujuan") { TujuanScreen(nav) }
        composable("materi") { MateriListScreen(nav) }
        composable("materi/{i}", arguments = listOf(navArgument("i") { type = NavType.IntType })) {
            MateriDetailScreen(nav, it.arguments?.getInt("i") ?: 0)
        }
        composable("video") { VideoScreen(nav) }
        composable("simulasi") { SimulasiScreen(nav) }
        composable("praktikum") { PraktikumScreen(nav) }
        composable("lkpd") { LkpdListScreen(nav) }
        composable("lkpd/{no}", arguments = listOf(navArgument("no") { type = NavType.IntType })) {
            LkpdDetailScreen(nav, it.arguments?.getInt("no") ?: 1)
        }
        composable("sensor") { SensorScreen(nav) }
        composable("analisis") { AnalisisScreen(nav) }
        composable("latihan") { LatihanScreen(nav) }
        composable("kuis") { KuisScreen(nav) }
        composable("rangkuman") { RangkumanScreen(nav) }
        composable("evaluasi") { EvaluasiScreen(nav) }
        composable("tentang") { TentangScreen(nav) }
    }
}
