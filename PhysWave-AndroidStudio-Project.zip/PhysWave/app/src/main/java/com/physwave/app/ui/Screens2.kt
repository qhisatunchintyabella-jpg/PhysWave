package com.physwave.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.physwave.app.data.*

// ============================ PRAKTIKUM ============================
@Composable
private fun NumberedList(items: List<String>) {
    items.forEachIndexed { i, s ->
        Row {
            Text("${i + 1}.", fontWeight = FontWeight.Bold, color = Blue700, modifier = Modifier.width(26.dp))
            Body(s)
        }
    }
}

@Composable
fun PraktikumScreen(nav: NavController) {
    PwScreen("Praktikum", nav) {
        PwCard(container = Blue50) {
            Text("🔬 ${PraktikumData.judul}", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Blue900)
            Body("Praktikum sederhana dan aman untuk dilakukan berkelompok di rumah atau di kelas.")
        }
        PwCard { Heading("A. Tujuan"); NumberedList(PraktikumData.tujuan) }
        PwCard { Heading("B. Dasar Teori"); PraktikumData.dasarTeori.forEach { Body(it) }
            Text("f = n / t     T = 1 / f     v = λ × f", fontWeight = FontWeight.Bold, color = Blue900, fontSize = 16.sp)
        }
        PwCard { Heading("C. Alat dan Bahan"); PraktikumData.alatBahan.forEach { Body("• $it") } }
        PwCard { Heading("D. Langkah Kerja"); NumberedList(PraktikumData.langkah) }
        PwCard {
            Heading("E. Tabel Data")
            Body("Isi tabel berikut pada menu Analisis Data → tab Tabel. Kolom T dan v dihitung otomatis oleh aplikasi.")
            Text(PraktikumData.kolomTabel.joinToString("  |  "), fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Blue700)
            PwButton("Buka Tabel Data", Modifier.fillMaxWidth()) { nav.navigate("analisis") }
        }
        PwCard {
            Heading("F. Analisis")
            PraktikumData.panduanAnalisis.forEach { Body("• $it") }
            Body("Jawab enam pertanyaan analisis pada menu Analisis Data → tab Analisis.")
        }
        PwCard {
            Heading("G. Kesimpulan")
            Body(PraktikumData.harapanTeori)
            PwButton("Tulis Kesimpulan", Modifier.fillMaxWidth()) { nav.navigate("analisis") }
        }
    }
}

// ============================ LKPD ============================
@Composable
fun LkpdListScreen(nav: NavController) {
    PwScreen("LKPD Digital", nav) {
        PwCard(container = Blue50) {
            Body("Kerjakan LKPD langsung di aplikasi. Semua jawaban tersimpan otomatis di HP Anda dan tetap ada walau aplikasi ditutup.")
        }
        daftarLkpd.forEach { l ->
            val terisi = Store.countFilled("lkpd${l.no}_")
            Card(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { nav.navigate("lkpd/${l.no}") },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(Blue700, CircleShape), contentAlignment = Alignment.Center) {
                        Text("${l.no}", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("LKPD ${l.no}", fontSize = 12.sp, color = Blue500, fontWeight = FontWeight.Bold)
                        Text(l.judul, fontWeight = FontWeight.SemiBold, color = Blue900)
                        Text(if (terisi > 0) "$terisi kolom terisi" else "Belum dikerjakan", fontSize = 11.sp, color = TextDark)
                    }
                    Text("›", fontSize = 26.sp, color = Blue700)
                }
            }
        }
    }
}

@Composable
fun LkpdDetailScreen(nav: NavController, no: Int) {
    val l = daftarLkpd.firstOrNull { it.no == no } ?: daftarLkpd[0]
    PwScreen("LKPD ${l.no}", nav) {
        PwCard(container = Blue50) {
            Text(l.judul, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Blue900)
        }
        PwCard { Heading("Tujuan"); Body(l.tujuan) }
        PwCard { Heading("Petunjuk"); NumberedList(l.petunjuk) }
        PwCard { Heading("Kegiatan"); NumberedList(l.kegiatan) }
        PwCard {
            Heading(l.tabelJudul)
            l.barisLabel.forEachIndexed { r, rowLabel ->
                Text("${l.headerBaris}: $rowLabel", fontWeight = FontWeight.Bold, color = Blue700)
                l.kolom.forEachIndexed { c, kol ->
                    SavedField("lkpd${l.no}_t${r}_$c", kol, minLines = 1)
                }
                Spacer(Modifier.height(4.dp))
            }
        }
        PwCard {
            Heading("Pertanyaan Analisis")
            l.pertanyaan.forEachIndexed { i, q ->
                Body("${i + 1}. $q")
                SavedField("lkpd${l.no}_q$i", "Jawaban ${i + 1}", minLines = 2)
                Spacer(Modifier.height(4.dp))
            }
        }
        PwCard {
            Heading("Kesimpulan")
            Body("Tuliskan kesimpulan dari kegiatan ini dengan kata-kata Anda sendiri.")
            SavedField("lkpd${l.no}_k", "Kesimpulan", minLines = 3)
        }
    }
}
