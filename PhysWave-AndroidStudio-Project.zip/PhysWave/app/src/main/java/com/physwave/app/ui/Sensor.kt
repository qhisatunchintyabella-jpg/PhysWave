package com.physwave.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

@Composable
fun SensorScreen(nav: NavController) {
    var tab by remember { mutableIntStateOf(0) }
    PwScreen("Eksperimen Sensor HP", nav) {
        TabRow(selectedTabIndex = tab, containerColor = Color.White, contentColor = Blue700) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("📳 Accelerometer") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("🎤 Mikrofon") })
        }
        if (tab == 0) AccelPanel() else MicPanel()
    }
}

@Composable
private fun WarningCard(title: String, msg: String) {
    PwCard(container = Color(0xFFFFEBEE)) {
        Text("⚠️ $title", fontWeight = FontWeight.Bold, color = RedBad)
        Body(msg)
    }
}

// Estimasi periode dari sinyal (zero-crossing dengan histeresis)
private fun estimasiPeriode(t: List<Float>, y: List<Float>): Double? {
    val n = min(t.size, y.size)
    if (n < 30) return null
    var mean = 0.0
    for (i in 0 until n) mean += y[i]
    mean /= n
    var mn = Double.MAX_VALUE; var mx = -Double.MAX_VALUE
    for (i in 0 until n) { val d = y[i] - mean; if (d < mn) mn = d; if (d > mx) mx = d }
    val amp = (mx - mn) / 2
    if (amp < 0.15) return null
    val h = 0.2 * amp
    var low = false
    val cross = ArrayList<Float>()
    for (i in 0 until n) {
        val d = y[i] - mean
        if (d < -h) low = true
        else if (d > h && low) { cross.add(t[i]); low = false }
    }
    if (cross.size < 3) return null
    return (cross.last() - cross.first()).toDouble() / (cross.size - 1)
}

// ============================ ACCELEROMETER ============================
@Composable
fun AccelPanel() {
    val ctx = LocalContext.current
    val sm = remember { ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager }
    val sensor = remember { sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) }
    if (sm == null || sensor == null) {
        WarningCard(
            "Sensor accelerometer tidak tersedia",
            "Perangkat ini tidak memiliki sensor accelerometer, sehingga eksperimen ini tidak dapat dijalankan. Anda tetap dapat memakai semua menu lain di aplikasi."
        )
        return
    }

    val maxSamples = 4000
    var running by remember { mutableStateOf(false) }
    val samples = remember { mutableStateListOf<FloatArray>() } // [t, x, y, z]
    var t0 by remember { mutableLongStateOf(-1L) }

    DisposableEffect(running) {
        if (!running) {
            onDispose { }
        } else {
            val l = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    if (e.values.size < 3) return
                    if (t0 < 0) t0 = e.timestamp
                    samples.add(floatArrayOf((e.timestamp - t0) / 1e9f, e.values[0], e.values[1], e.values[2]))
                    if (samples.size >= maxSamples) running = false
                }
                override fun onAccuracyChanged(s: Sensor?, a: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
            onDispose { sm.unregisterListener(l) }
        }
    }

    // sumbu dengan variasi terbesar
    val list = samples.toList()
    var axis = 1
    if (list.size > 5) {
        var best = -1.0
        for (a in 1..3) {
            var m = 0.0
            list.forEach { m += it[a] }
            m /= list.size
            var v = 0.0
            list.forEach { v += (it[a] - m) * (it[a] - m) }
            if (v > best) { best = v; axis = a }
        }
    }
    val axisName = when (axis) { 1 -> "X"; 2 -> "Y"; else -> "Z" }
    val ts = list.map { it[0] }
    val raw = list.map { it[axis] }
    val mean = if (raw.isEmpty()) 0f else raw.sum() / raw.size
    val ys = raw.map { it - mean }
    val T = estimasiPeriode(ts, ys)

    PwCard(container = Blue50) {
        Heading("Analisis Getaran Menggunakan Accelerometer HP")
        Body("1. Letakkan HP pada benda yang bergetar atau ayunan (misalnya pegas, penggaris yang digetarkan, atau bandul). 2. Tekan START. 3. Getarkan selama 5–20 detik. 4. Tekan STOP dan baca estimasi periode dan frekuensi.")
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PwButton("START", Modifier.weight(1f), enabled = !running) {
            samples.clear(); t0 = -1L; running = true
        }
        PwButton("STOP", Modifier.weight(1f), enabled = running, color = RedBad) { running = false }
        PwButton("RESET", Modifier.weight(1f), color = Color(0xFF546E7A)) {
            running = false; samples.clear(); t0 = -1L
        }
    }
    PwCard {
        val last = list.lastOrNull()
        Body("Status: ${if (running) "merekam…" else "berhenti"}")
        Body("Waktu: ${fmt((last?.get(0) ?: 0f).toDouble(), 2)} s   •   Jumlah data: ${list.size}")
        Body("Percepatan terakhir (sumbu $axisName): ${fmt((last?.get(axis) ?: 0f).toDouble(), 2)} m/s²")
    }
    PlotChart(
        "Grafik Percepatan Sumbu $axisName terhadap Waktu",
        "Waktu t (s)", "Percepatan a (m/s²)", ts, ys, asLine = true, height = 240.dp
    )
    PwCard(container = Blue50) {
        Heading("Estimasi")
        if (T != null && T > 0) {
            Body("Periode  T ≈ ${fmt(T, 3)} s")
            Body("Frekuensi  f = 1/T ≈ ${fmt(1.0 / T, 3)} Hz")
        } else {
            Body("Belum dapat diestimasi. Getarkan HP dengan simpangan yang cukup besar dan teratur, minimal 3 getaran lengkap.")
        }
        Body("Catatan: grafik menampilkan percepatan pada sumbu dengan variasi terbesar setelah nilai rata-rata (termasuk gravitasi) dikurangkan.", Color(0xFF546E7A))
    }
    PwCard {
        Body("Hasil pengukuran merupakan estimasi dan dapat dipengaruhi oleh kualitas sensor, laju pencuplikan sensor, cara HP diletakkan, dan kondisi lingkungan.", Color(0xFF546E7A))
    }
}

// ============================ MIKROFON ============================
private fun estimasiFrekuensi(x: ShortArray, n: Int, sr: Int): Double? {
    var mean = 0.0
    for (i in 0 until n) mean += x[i]
    mean /= n
    val a = DoubleArray(n) { x[it] - mean }
    var r0 = 0.0
    for (v in a) r0 += v * v
    val rms = sqrt(r0 / n)
    if (rms < 150.0) return null
    val minLag = sr / 2000
    val maxLag = min(sr / 70, n / 2)
    val r = DoubleArray(maxLag + 2)
    var best = -Double.MAX_VALUE
    for (lag in (minLag - 1)..(maxLag + 1)) {
        var s = 0.0
        val lim = n - lag
        for (i in 0 until lim) s += a[i] * a[i + lag]
        r[lag] = s
        if (lag in minLag..maxLag && s > best) best = s
    }
    if (best < 0.3 * r0) return null
    var pick = -1
    for (lag in minLag..maxLag) {
        if (r[lag] >= 0.85 * best && r[lag] >= r[lag - 1] && r[lag] >= r[lag + 1]) { pick = lag; break }
    }
    if (pick < 0) return null
    val y0 = r[pick - 1]; val y1 = r[pick]; val y2 = r[pick + 1]
    val den = y0 - 2 * y1 + y2
    val shift = if (den != 0.0) 0.5 * (y0 - y2) / den else 0.0
    val period = (pick + shift) / sr
    return if (period > 0) 1.0 / period else null
}

@SuppressLint("MissingPermission")
@Composable
fun MicPanel() {
    val ctx = LocalContext.current
    val hasMic = remember { ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE) }
    if (!hasMic) {
        WarningCard("Mikrofon tidak tersedia", "Perangkat ini tidak memiliki mikrofon sehingga eksperimen ini tidak dapat dijalankan. Anda tetap dapat memakai menu lain.")
        return
    }
    val sr = 44100
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Tekan START untuk mulai merekam.") }
    var wave by remember { mutableStateOf(listOf<Float>()) }
    var waveT by remember { mutableStateOf(listOf<Float>()) }
    var freq by remember { mutableStateOf<Double?>(null) }
    var izinDitolak by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { izinDitolak = false; running = true } else izinDitolak = true
    }

    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        status = "Merekam… bunyikan nada (siulan, garpu tala, atau nada dari HP lain) dekat mikrofon."
        withContext(Dispatchers.IO) {
            var rec: AudioRecord? = null
            try {
                val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (minBuf <= 0) throw IllegalStateException("Format audio tidak didukung")
                rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 16384)
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Mikrofon tidak dapat dibuka")
                rec.startRecording()
                val buf = ShortArray(4096)
                val recent = ArrayList<Double>()
                while (isActive) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) throw IllegalStateException("Gagal membaca mikrofon")
                    if (n < 2048) continue
                    var mean = 0.0
                    for (i in 0 until n) mean += buf[i]
                    mean /= n
                    var mx = 1.0
                    for (i in 0 until n) mx = max(mx, abs(buf[i] - mean))
                    val cnt = 700
                    val w = ArrayList<Float>(cnt / 2)
                    val tt = ArrayList<Float>(cnt / 2)
                    var i = 0
                    while (i < cnt) {
                        w.add(((buf[i] - mean) / mx).toFloat())
                        tt.add(i * 1000f / sr)
                        i += 2
                    }
                    wave = w; waveT = tt
                    val f = estimasiFrekuensi(buf, n, sr)
                    if (f != null) {
                        recent.add(f)
                        if (recent.size > 7) recent.removeAt(0)
                        freq = recent.sorted()[recent.size / 2]
                    } else {
                        recent.clear(); freq = null
                    }
                }
            } catch (e: Exception) {
                status = "Tidak dapat menggunakan mikrofon: ${e.message ?: "kesalahan tidak diketahui"}"
            } finally {
                try { rec?.stop() } catch (e: Exception) { }
                try { rec?.release() } catch (e: Exception) { }
            }
        }
        running = false
    }

    PwCard(container = Blue50) {
        Heading("Analisis Frekuensi Bunyi")
        Body("Mikrofon merekam bunyi, lalu aplikasi menghitung bentuk gelombang dan memperkirakan frekuensi dominannya. Rekaman tidak disimpan dan tidak dikirim ke mana pun.")
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PwButton("START", Modifier.weight(1f), enabled = !running) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                izinDitolak = false; running = true
            } else launcher.launch(Manifest.permission.RECORD_AUDIO)
        }
        PwButton("STOP", Modifier.weight(1f), enabled = running, color = RedBad) {
            running = false; status = "Perekaman dihentikan."
        }
        PwButton("RESET", Modifier.weight(1f), color = Color(0xFF546E7A)) {
            running = false; wave = emptyList(); waveT = emptyList(); freq = null
            status = "Data direset. Tekan START untuk mulai lagi."
        }
    }
    if (izinDitolak) {
        WarningCard("Izin mikrofon ditolak", "Aktifkan izin Mikrofon untuk PHYSWAVE pada Pengaturan HP → Aplikasi → PHYSWAVE → Izin, agar eksperimen ini dapat dipakai.")
    }
    PwCard { Body(status) }
    PlotChart(
        "Bentuk Gelombang Bunyi terhadap Waktu",
        "Waktu t (ms)", "Amplitudo relatif", waveT, wave, asLine = true, height = 220.dp
    )
    PwCard(container = Blue50) {
        Heading("Estimasi")
        val f = freq
        if (f != null) {
            Body("Frekuensi dominan  f ≈ ${fmt(f, 1)} Hz")
            Body("Periode  T = 1/f ≈ ${fmt(1000.0 / f, 3)} ms  (${fmt(1.0 / f, 5)} s)")
        } else {
            Body(if (running) "Belum ada nada yang jelas terdeteksi. Bunyikan nada tunggal yang cukup keras dan dekat dengan mikrofon." else "Belum ada hasil.")
        }
    }
    PwCard {
        Body("Hasil pengukuran merupakan estimasi dan dapat dipengaruhi oleh kualitas mikrofon, kebisingan lingkungan, jarak sumber bunyi, dan nada yang mengandung banyak harmonik. Rentang estimasi sekitar 70–2000 Hz.", Color(0xFF546E7A))
    }
}
