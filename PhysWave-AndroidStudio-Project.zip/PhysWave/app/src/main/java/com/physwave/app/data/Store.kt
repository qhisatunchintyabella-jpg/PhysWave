package com.physwave.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class DataRow(val f: Double, val lambda: Double) {
    val t: Double get() = 1.0 / f
    val v: Double get() = lambda * f
}

data class Hasil(
    val skor: Int,
    val skorMaks: Int,
    val benar: Int,
    val total: Int,
    val salahIds: List<Int>
)

object Store {
    private lateinit var p: SharedPreferences

    fun init(c: Context) {
        if (!::p.isInitialized) {
            p = c.applicationContext.getSharedPreferences("physwave", Context.MODE_PRIVATE)
        }
    }

    fun getText(k: String, d: String = ""): String = p.getString(k, d) ?: d
    fun putText(k: String, v: String) { p.edit().putString(k, v).apply() }

    fun countFilled(prefix: String): Int =
        p.all.entries.count { it.key.startsWith(prefix) && (it.value as? String)?.isNotBlank() == true }

    fun loadData(): MutableList<DataRow> {
        val out = mutableListOf<DataRow>()
        try {
            val arr = JSONArray(p.getString("data_rows", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(DataRow(o.getDouble("f"), o.getDouble("l")))
            }
        } catch (e: Exception) { /* abaikan data rusak */ }
        return out
    }

    fun saveData(list: List<DataRow>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("f", it.f).put("l", it.lambda)) }
        p.edit().putString("data_rows", arr.toString()).apply()
    }

    fun saveHasil(key: String, r: Hasil) {
        p.edit().putString(
            "res_$key",
            "${r.skor},${r.skorMaks},${r.benar},${r.total},${r.salahIds.joinToString("|")}"
        ).apply()
    }

    fun loadHasil(key: String): Hasil? {
        val s = p.getString("res_$key", null) ?: return null
        val a = s.split(",")
        if (a.size < 5) return null
        return try {
            Hasil(
                a[0].toInt(), a[1].toInt(), a[2].toInt(), a[3].toInt(),
                if (a[4].isBlank()) emptyList() else a[4].split("|").map { it.toInt() }
            )
        } catch (e: Exception) { null }
    }
}
