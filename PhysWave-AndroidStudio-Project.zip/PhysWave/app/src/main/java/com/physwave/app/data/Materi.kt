package com.physwave.app.data

data class Materi(
    val kode: String,
    val judul: String,
    val emoji: String,
    val pengertian: String,
    val penjelasan: String,
    val rumus: List<String>,
    val simbol: String,
    val satuan: String,
    val contoh: String,
    val sehari: String,
    val ilustrasi: String
)

val tujuanPembelajaran = listOf(
    "Menjelaskan konsep dasar gelombang.",
    "Mengidentifikasi jenis-jenis gelombang.",
    "Menentukan amplitudo, panjang gelombang, frekuensi, dan periode.",
    "Menggunakan hubungan T = 1/f.",
    "Menggunakan persamaan v = λf.",
    "Menganalisis gejala gelombang.",
    "Melakukan eksperimen sederhana tentang gelombang.",
    "Mengolah dan menganalisis data hasil eksperimen.",
    "Menghubungkan konsep gelombang dengan kehidupan sehari-hari."
)

val daftarMateri = listOf(
    Materi(
        "A", "Pengertian Gelombang", "🌊",
        "Gelombang adalah getaran yang merambat dan memindahkan energi dari satu tempat ke tempat lain.",
        "Saat batu dijatuhkan ke kolam, riak air menyebar sampai ke tepi. Air hanya naik-turun di tempatnya, sedangkan yang berpindah adalah energinya. Jadi gelombang memindahkan energi, bukan memindahkan medium (zat perantaranya).",
        emptyList(), "", "",
        "Gelombang pada tali yang digoyangkan, riak air, dan bunyi.",
        "Ombak di pantai, suara musik dari speaker, dan sinyal Wi-Fi atau sinyal HP.",
        "transversal"
    ),
    Materi(
        "B", "Jenis-Jenis Gelombang", "🧭",
        "Gelombang dapat dikelompokkan berdasarkan medium perambatannya dan arah getarnya.",
        "Berdasarkan medium: (1) gelombang mekanik, butuh medium, contoh bunyi dan gelombang tali; (2) gelombang elektromagnetik, tidak butuh medium, contoh cahaya dan gelombang radio. Berdasarkan arah getar: gelombang transversal dan gelombang longitudinal.",
        emptyList(), "", "",
        "Bunyi = mekanik longitudinal. Gelombang tali = mekanik transversal. Cahaya = elektromagnetik transversal.",
        "Cahaya Matahari sampai ke Bumi melewati ruang hampa, tetapi bunyi tidak dapat merambat di ruang hampa.",
        "sine"
    ),
    Materi(
        "C", "Gelombang Transversal", "↕️",
        "Gelombang transversal adalah gelombang yang arah getarnya tegak lurus terhadap arah rambatnya.",
        "Bentuknya berupa bukit dan lembah. Satu gelombang terdiri dari satu bukit dan satu lembah. Titik tertinggi disebut puncak, titik terendah disebut dasar.",
        listOf("1 gelombang = 1 bukit + 1 lembah"), "", "",
        "Tali yang digoyangkan naik-turun. Getarannya ke atas-bawah, rambatannya ke depan.",
        "Cahaya dan gelombang radio adalah gelombang transversal. Senar gitar yang dipetik juga bergetar transversal.",
        "transversal"
    ),
    Materi(
        "D", "Gelombang Longitudinal", "↔️",
        "Gelombang longitudinal adalah gelombang yang arah getarnya searah dengan arah rambatnya.",
        "Bentuknya berupa rapatan (partikel berdekatan) dan renggangan (partikel berjauhan). Satu gelombang terdiri dari satu rapatan dan satu renggangan.",
        listOf("1 gelombang = 1 rapatan + 1 renggangan"), "", "",
        "Slinky (pegas) yang didorong dan ditarik searah panjangnya.",
        "Bunyi dari speaker merambat di udara sebagai gelombang longitudinal. Gelombang ultrasonik pada USG juga longitudinal.",
        "longitudinal"
    ),
    Materi(
        "E", "Amplitudo", "📏",
        "Amplitudo adalah simpangan terbesar gelombang, diukur dari titik setimbang (garis tengah).",
        "Makin besar amplitudo, makin besar energi gelombang. Pada bunyi, amplitudo besar membuat suara lebih keras. Pada cahaya, amplitudo besar membuat cahaya lebih terang.",
        listOf("Energi gelombang sebanding dengan kuadrat amplitudo: E ∝ A²"),
        "A = amplitudo", "meter (m); dapat juga cm",
        "Tali digetarkan hingga puncaknya 5 cm di atas titik setimbang, maka A = 5 cm = 0,05 m.",
        "Saat volume speaker dinaikkan, amplitudo gelombang bunyi membesar sehingga suara terdengar lebih keras.",
        "amplitudo"
    ),
    Materi(
        "F", "Panjang Gelombang", "↔",
        "Panjang gelombang adalah jarak yang ditempuh gelombang dalam satu periode. Pada gelombang transversal, itu jarak dua bukit (atau dua lembah) berurutan. Pada gelombang longitudinal, itu jarak dua rapatan berurutan.",
        "Panjang gelombang menunjukkan 'ukuran' satu gelombang lengkap. Gelombang dengan frekuensi tinggi pada medium yang sama memiliki panjang gelombang lebih pendek.",
        listOf("λ = v × T", "λ = v / f"),
        "λ (lambda) = panjang gelombang; v = cepat rambat; T = periode; f = frekuensi", "meter (m)",
        "Jarak dua bukit berurutan pada tali adalah 0,4 m, maka λ = 0,4 m.",
        "Gelombang radio FM 100 MHz memiliki λ sekitar 3 m. Cahaya tampak memiliki λ sangat pendek, sekitar 400–700 nm.",
        "period"
    ),
    Materi(
        "G", "Frekuensi", "🔁",
        "Frekuensi adalah banyaknya getaran (atau gelombang) yang terjadi dalam satu sekon.",
        "Makin banyak getaran per sekon, makin besar frekuensinya. Pada bunyi, frekuensi menentukan tinggi rendah nada.",
        listOf("f = n / t", "f = 1 / T"),
        "f = frekuensi; n = banyak getaran; t = waktu; T = periode", "hertz (Hz), 1 Hz = 1 getaran per sekon",
        "Tali bergetar 20 kali dalam 10 s, maka f = 20 / 10 = 2 Hz.",
        "Listrik PLN berfrekuensi 50 Hz. Telinga manusia dapat mendengar sekitar 20 Hz sampai 20.000 Hz.",
        "period"
    ),
    Materi(
        "H", "Periode", "⏱️",
        "Periode adalah waktu yang diperlukan untuk satu getaran (satu gelombang lengkap).",
        "Periode diukur dengan stopwatch: bagi waktu total dengan banyak getaran. Makin cepat getaran, makin kecil periodenya.",
        listOf("T = t / n", "T = 1 / f"),
        "T = periode; t = waktu total; n = banyak getaran", "sekon (s)",
        "20 getaran memerlukan waktu 10 s, maka T = 10 / 20 = 0,5 s.",
        "Ayunan di taman yang satu kali bolak-balik penuh dalam 2 s memiliki periode 2 s.",
        "period"
    ),
    Materi(
        "I", "Cepat Rambat Gelombang", "🚀",
        "Cepat rambat gelombang adalah jarak yang ditempuh gelombang tiap satuan waktu.",
        "Cepat rambat dipengaruhi oleh medium. Pada tali, semakin tegang tali semakin cepat gelombang merambat. Bunyi merambat lebih cepat di air daripada di udara.",
        listOf("v = s / t"),
        "v = cepat rambat; s = jarak tempuh; t = waktu", "meter per sekon (m/s)",
        "Gelombang menempuh 6 m dalam 4 s, maka v = 6 / 4 = 1,5 m/s.",
        "Bunyi di udara sekitar 340 m/s. Itu sebabnya guntur terdengar beberapa saat setelah kilat terlihat.",
        "speed"
    ),
    Materi(
        "J", "Hubungan Frekuensi dan Periode", "🔗",
        "Frekuensi dan periode saling berkebalikan (berbanding terbalik).",
        "Jika frekuensi makin besar, periode makin kecil. Hasil kali keduanya selalu sama dengan 1.",
        listOf("T = 1 / f", "f = 1 / T", "f × T = 1"),
        "T = periode; f = frekuensi", "T dalam s; f dalam Hz",
        "f = 5 Hz maka T = 1/5 = 0,2 s. Jika T = 0,01 s maka f = 1/0,01 = 100 Hz.",
        "Nada tinggi punya frekuensi besar, sehingga periodenya sangat kecil.",
        "period"
    ),
    Materi(
        "K", "Persamaan v = λf", "🧮",
        "Cepat rambat gelombang sama dengan panjang gelombang dikali frekuensi.",
        "Dalam satu periode T, gelombang menempuh satu panjang gelombang λ. Jadi v = λ/T = λf. Pada medium yang sama (v tetap), jika f makin besar maka λ makin kecil.",
        listOf("v = λ × f", "v = λ / T", "λ = v / f", "f = v / λ"),
        "v = cepat rambat; λ = panjang gelombang; f = frekuensi; T = periode", "v dalam m/s; λ dalam m; f dalam Hz",
        "λ = 0,5 m dan f = 4 Hz, maka v = 0,5 × 4 = 2 m/s.",
        "Pada senar gitar, nada menjadi lebih tinggi ketika senar diperpendek, karena panjang gelombang pada senar menjadi lebih kecil.",
        "speed"
    ),
    Materi(
        "L", "Pemantulan (Refleksi)", "🪞",
        "Pemantulan adalah peristiwa gelombang memantul ketika mengenai penghalang.",
        "Hukum pemantulan: sudut datang sama dengan sudut pantul, dan garis datang, garis normal, serta garis pantul berada pada satu bidang. Pada pemantulan, f, λ, dan v gelombang tidak berubah karena mediumnya tetap.",
        listOf("θi = θr"),
        "θi = sudut datang; θr = sudut pantul (diukur dari garis normal)", "derajat (°)",
        "Sinar datang dengan sudut 30° akan dipantulkan dengan sudut 30°.",
        "Gema di lembah atau gedung kosong, cermin, dan sonar atau USG yang memakai pantulan gelombang.",
        "reflect"
    ),
    Materi(
        "M", "Pembiasan (Refraksi)", "🔍",
        "Pembiasan adalah pembelokan arah rambat gelombang ketika berpindah ke medium lain.",
        "Pembelokan terjadi karena cepat rambat berubah. Frekuensi tetap, sedangkan v dan λ berubah. Jika masuk ke medium yang membuat gelombang lebih lambat, gelombang membelok mendekati garis normal. Jika lebih cepat, gelombang membelok menjauhi garis normal.",
        listOf("sin θ1 / sin θ2 = v1 / v2 = λ1 / λ2"),
        "θ1, θ2 = sudut di medium 1 dan 2; v1, v2 = cepat rambat di medium 1 dan 2", "derajat (°); m/s",
        "Gelombang air masuk ke daerah dangkal: melambat, λ mengecil, dan arahnya membelok.",
        "Sedotan tampak patah di dalam gelas berisi air, pelangi, dan lensa kacamata.",
        "refract"
    ),
    Materi(
        "N", "Difraksi", "🌀",
        "Difraksi adalah pelenturan atau penyebaran gelombang ketika melewati celah sempit atau tepi penghalang.",
        "Difraksi tampak jelas jika lebar celah sebanding atau lebih kecil daripada panjang gelombang. Gelombang lurus yang melewati celah sempit menyebar seperti lingkaran.",
        emptyList(), "", "",
        "Gelombang air lurus melewati celah sempit lalu keluar berbentuk lingkaran.",
        "Suara dari ruangan lain terdengar melalui pintu yang terbuka walau orangnya tidak terlihat.",
        "diffract"
    ),
    Materi(
        "O", "Interferensi", "➕",
        "Interferensi adalah perpaduan dua gelombang atau lebih yang bertemu di satu tempat.",
        "Interferensi konstruktif: gelombang sefase, amplitudo saling menguatkan. Interferensi destruktif: gelombang berlawanan fase, amplitudo saling melemahkan. Syaratnya gelombang berasal dari sumber yang koheren (frekuensi sama dan beda fase tetap).",
        listOf("Konstruktif: Δs = nλ", "Destruktif: Δs = (n + ½)λ", "n = 0, 1, 2, ..."),
        "Δs = selisih lintasan; λ = panjang gelombang; n = bilangan bulat", "meter (m)",
        "Dua speaker memancarkan nada yang sama. Di posisi tertentu bunyi terdengar keras, di posisi lain terdengar lemah.",
        "Headphone peredam bising (noise-cancelling) dan warna-warni pada gelembung sabun.",
        "interf"
    ),
    Materi(
        "P", "Polarisasi", "🕶️",
        "Polarisasi adalah pembatasan arah getar gelombang sehingga hanya bergetar pada satu arah.",
        "Hanya gelombang transversal yang dapat terpolarisasi. Gelombang longitudinal seperti bunyi tidak dapat dipolarisasi karena arah getarnya searah dengan arah rambat. Polarisasi dapat terjadi karena penyerapan, pemantulan, pembiasan ganda, atau hamburan.",
        emptyList(), "", "",
        "Tali melewati celah vertikal: hanya getaran vertikal yang lolos.",
        "Kacamata polaroid mengurangi silau, layar LCD HP, dan filter polarisasi pada kamera.",
        "polar"
    ),
    Materi(
        "Q", "Penerapan Gelombang dalam Kehidupan", "🏥",
        "Banyak teknologi bekerja dengan memanfaatkan sifat-sifat gelombang.",
        "Sonar dan USG memakai pantulan bunyi. Radio, TV, dan sinyal HP memakai gelombang elektromagnetik. Oven microwave memakai gelombang mikro. Rontgen memakai sinar-X. Serat optik memakai pemantulan cahaya. Peredam bising memakai interferensi. Kacamata polaroid memakai polarisasi.",
        listOf("Sonar: d = v × t / 2"),
        "d = kedalaman atau jarak; v = cepat rambat; t = waktu pergi-pulang", "d dalam m; v dalam m/s; t dalam s",
        "Bunyi sonar kapal kembali setelah 2 s. Jika v air laut 1.500 m/s maka d = 1.500 × 2 / 2 = 1.500 m.",
        "Kelelawar menentukan posisi mangsa dengan memancarkan bunyi ultrasonik lalu menangkap pantulannya.",
        "apps"
    )
)
