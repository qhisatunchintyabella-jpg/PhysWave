package com.physwave.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.physwave.app.data.*
import kotlin.math.sqrt

// ============================ ANALISIS DATA ============================
private fun pearson(a: List<Double>, b: List<Double>): Double? {
    val n = a.size
    if (n < 3) return null
    val ma = a.average(); val mb = b.average()
    var sab = 0.0; var saa = 0.0; var sbb = 0.0
    for (i in 0 until n) {
        sab += (a[i] - ma) * (b[i] - mb)
        saa += (a[i] - ma) * (a[i] - ma)
        sbb += (b[i] - mb) * (b[i] - mb)
    }
    if (saa == 0.0 || sbb == 0.0) return null
    return sab / sqrt(saa * sbb)
}

private fun ringkasan(d: List<DataRow>): List<String> {
    if (d.isEmpty()) return listOf("Belum ada data. Tambahkan data pada tab Tabel terlebih dahulu.")
    val out = mutableListOf<String>()
    out += "Jumlah data: ${d.size}."
    val fMin = d.minByOrNull { it.f }!!
    val fMax = d.maxByOrNull { it.f }!!
    if (fMax.f != fMin.f) {
        out += "Frekuensi terkecil ${fmt(fMin.f)} Hz memiliki periode ${fmt(fMin.t, 4)} s, sedangkan frekuensi terbesar ${fmt(fMax.f)} Hz memiliki periode ${fmt(fMax.t, 4)} s. Frekuensi yang lebih besar menghasilkan periode yang lebih kecil, sesuai T = 1/f."
    } else {
        out += "Semua data memiliki frekuensi yang sama (${fmt(fMin.f)} Hz), sehingga pengaruh frekuensi belum dapat dibandingkan. Tambahkan data dengan frekuensi berbeda."
    }
    val vs = d.map { it.v }
    val vMean = vs.average()
    out += "Cepat rambat rata-rata v = ${fmt(vMean, 3)} m/s (terkecil ${fmt(vs.min(), 3)} m/s, terbesar ${fmt(vs.max(), 3)} m/s)."
    if (d.size < 3) {
        out += "Tambahkan minimal 3 data untuk menilai apakah cepat rambat relatif tetap dan bagaimana hubungan λ dengan f."
    } else {
        val sd = sqrt(vs.map { (it - vMean) * (it - vMean) }.average())
        val cv = if (vMean != 0.0) sd / vMean else 0.0
        if (cv <= 0.10) {
            out += "Nilai v bervariasi kecil (sekitar ${fmt(cv * 100, 1)}%), sehingga cepat rambat dapat dianggap relatif tetap pada percobaan ini."
            val r = pearson(d.map { it.f }, d.map { it.lambda })
            if (r != null && r < -0.7) out += "Panjang gelombang cenderung mengecil ketika frekuensi membesar (korelasi ${fmt(r, 2)}), sesuai v = λf dengan v tetap."
        } else {
            out += "Nilai v bervariasi cukup besar (sekitar ${fmt(cv * 100, 1)}%). Ini dapat disebabkan perubahan kondisi medium (misalnya ketegangan tali) atau kesalahan pengukuran."
        }
    }
    return out
}

@Composable
fun AnalisisScreen(nav: NavController) {
    var tab by remember { mutableIntStateOf(0) }
    val data = remember { mutableStateListOf<DataRow>().apply { addAll(Store.loadData()) } }
    val tabs = listOf("Tabel", "Grafik", "Analisis", "Kesimpulan")

    var showDialog by remember { mutableStateOf(false) }
    var editIndex by remember { mutableIntStateOf(-1) }
    var showReset by remember { mutableStateOf(false) }

    PwScreen("Analisis Data", nav) {
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp, containerColor = Color.White, contentColor = Blue700) {
            tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        when (tab) {
            0 -> {
                PwCard(container = Blue50) {
                    Body("Masukkan frekuensi (f) dan panjang gelombang (λ) dari eksperimen. Aplikasi menghitung otomatis T = 1/f dan v = λ × f. Data tersimpan di HP.")
                }
                PwCard {
                    Row(Modifier.fillMaxWidth()) {
                        listOf("No." to 0.6f, "f (Hz)" to 1f, "T (s)" to 1f, "λ (m)" to 1f, "v (m/s)" to 1.1f).forEach { (t, w) ->
                            Text(t, Modifier.weight(w), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Blue900, textAlign = TextAlign.Center)
                        }
                    }
                    HorizontalDivider()
                    if (data.isEmpty()) {
                        Body("Belum ada data. Tekan 'Tambah Data'.")
                    }
                    data.forEachIndexed { i, r ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            listOf("${i + 1}" to 0.6f, fmt(r.f, 3) to 1f, fmt(r.t, 4) to 1f, fmt(r.lambda, 3) to 1f, fmt(r.v, 3) to 1.1f).forEach { (t, w) ->
                                Text(t, Modifier.weight(w), fontSize = 12.sp, textAlign = TextAlign.Center, color = TextDark)
                            }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { editIndex = i; showDialog = true }) { Text("Edit") }
                            TextButton(onClick = { data.removeAt(i); Store.saveData(data) }) { Text("Hapus", color = RedBad) }
                        }
                        HorizontalDivider()
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PwButton("+ Tambah Data", Modifier.weight(1f)) { editIndex = -1; showDialog = true }
                    PwButton("Reset Data", Modifier.weight(1f), enabled = data.isNotEmpty(), color = RedBad) { showReset = true }
                }
            }
            1 -> {
                if (data.isEmpty()) {
                    PwCard { Body("Grafik dibuat otomatis dari data siswa. Tambahkan data pada tab Tabel terlebih dahulu.") }
                }
                val s1 = data.sortedBy { it.f }
                PlotChart(
                    "Grafik 1: Frekuensi (f) terhadap Periode (T)",
                    "Frekuensi f (Hz)", "Periode T (s)",
                    s1.map { it.f.toFloat() }, s1.map { it.t.toFloat() }, asLine = true, height = 250.dp
                )
                val s2 = data.sortedBy { it.lambda }
                PlotChart(
                    "Grafik 2: Panjang Gelombang (λ) terhadap Cepat Rambat (v)",
                    "Panjang gelombang λ (m)", "Cepat rambat v (m/s)",
                    s2.map { it.lambda.toFloat() }, s2.map { it.v.toFloat() }, asLine = true, height = 250.dp
                )
                PwCard {
                    Body("Catatan: pada Grafik 2, v = λ × f. Jika frekuensi setiap data berbeda, titik-titik tidak harus membentuk garis lurus. Bila frekuensi dijaga sama, v berbanding lurus dengan λ.", Color(0xFF546E7A))
                }
            }
            2 -> {
                PwCard(container = Blue50) { Body("Jawablah pertanyaan berikut berdasarkan tabel dan grafik Anda. Jawaban tersimpan otomatis.") }
                pertanyaanAnalisis.forEachIndexed { i, q ->
                    PwCard {
                        Body("${i + 1}. $q")
                        SavedField("analisis_q$i", "Jawaban ${i + 1}", minLines = 2)
                    }
                }
            }
            else -> {
                PwCard(container = Blue50) {
                    Heading("Ringkasan Otomatis dari Data")
                    ringkasan(data).forEach { Body("• $it") }
                    Body("Ringkasan ini hanya menyatakan hal yang dapat dihitung dari data Anda.", Color(0xFF546E7A))
                }
                PwCard {
                    Heading("Kesimpulan Saya")
                    Body("Tulis kesimpulan Anda berdasarkan data, grafik, dan jawaban analisis.")
                    SavedField("kesimpulan_siswa", "Kesimpulan", minLines = 5)
                }
            }
        }
    }

    if (showDialog) {
        val existing = data.getOrNull(editIndex)
        var fText by remember(editIndex, showDialog) { mutableStateOf(existing?.let { fmt(it.f, 6) } ?: "") }
        var lText by remember(editIndex, showDialog) { mutableStateOf(existing?.let { fmt(it.lambda, 6) } ?: "") }
        var error by remember(editIndex, showDialog) { mutableStateOf<String?>(null) }
        val fv = parseNum(fText); val lv = parseNum(lText)
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(if (existing == null) "Tambah Data" else "Edit Data") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(fText, { fText = it; error = null }, label = { Text("Frekuensi f (Hz)") }, singleLine = true)
                    OutlinedTextField(lText, { lText = it; error = null }, label = { Text("Panjang gelombang λ (m)") }, singleLine = true)
                    if (fv != null && lv != null && fv > 0 && lv > 0) {
                        Text("T = ${fmt(1 / fv, 4)} s   •   v = ${fmt(fv * lv, 3)} m/s", fontSize = 12.sp, color = Blue700)
                    }
                    error?.let { Text(it, color = RedBad, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (fv == null || lv == null || fv <= 0.0 || lv <= 0.0) {
                        error = "Isi f dan λ dengan angka lebih dari 0."
                    } else {
                        if (existing == null) data.add(DataRow(fv, lv)) else data[editIndex] = DataRow(fv, lv)
                        Store.saveData(data)
                        showDialog = false
                    }
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Batal") } }
        )
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Reset Data") },
            text = { Text("Semua data eksperimen akan dihapus. Lanjutkan?") },
            confirmButton = { TextButton(onClick = { data.clear(); Store.saveData(data); showReset = false }) { Text("Hapus semua", color = RedBad) } },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Batal") } }
        )
    }
}

// ============================ LATIHAN & KUIS ============================
@Composable
fun QuizRunner(nav: NavController, soal: List<Soal>, key: String, judul: String, intro: String) {
    var started by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    val answers = remember { mutableStateMapOf<Int, Int>() }
    var finished by remember { mutableStateOf(false) }
    val letters = listOf("A", "B", "C", "D", "E")

    PwScreen(judul, nav) {
        if (!started) {
            val prev = Store.loadHasil(key)
            PwCard(container = Blue50) {
                Heading(judul)
                Body(intro)
                Body("Jumlah soal: ${soal.size}   •   Skor maksimum: ${soal.sumOf { it.skor }}")
            }
            if (prev != null) {
                PwCard {
                    Label("Hasil terakhir")
                    Body("Skor ${prev.skor} dari ${prev.skorMaks}   •   Benar ${prev.benar}/${prev.total}")
                }
            }
            PwButton(if (prev == null) "Mulai" else "Mulai Lagi", Modifier.fillMaxWidth()) { started = true }
        } else if (!finished) {
            val q = soal[index]
            LinearProgressIndicator(
                progress = { (index + 1f) / soal.size },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
            )
            Text("Soal ${index + 1} dari ${soal.size}   •   ${q.kategori}   •   skor ${q.skor}", fontSize = 12.sp, color = Blue700, fontWeight = FontWeight.SemiBold)
            PwCard { Text(q.tanya, fontSize = 16.sp, lineHeight = 23.sp, fontWeight = FontWeight.SemiBold, color = TextDark) }
            q.opsi.forEachIndexed { i, o ->
                val sel = selected
                val bg = when {
                    sel == null -> Color.White
                    i == q.jawaban -> Color(0xFFC8E6C9)
                    i == sel -> Color(0xFFFFCDD2)
                    else -> Color.White
                }
                val borderColor = when {
                    sel == null -> Blue100
                    i == q.jawaban -> GreenOk
                    i == sel -> RedBad
                    else -> Blue100
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(bg)
                        .border(2.dp, borderColor, RoundedCornerShape(12.dp))
                        .clickable(enabled = sel == null) {
                            selected = i
                            answers[q.id] = i
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${letters[i]}.", fontWeight = FontWeight.Bold, color = Blue900, modifier = Modifier.width(28.dp))
                    Text(o, fontSize = 14.sp, color = TextDark)
                }
            }
            val sel = selected
            if (sel != null) {
                val ok = sel == q.jawaban
                PwCard(container = if (ok) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)) {
                    Text(
                        if (ok) "✅ Benar! +${q.skor} poin" else "❌ Belum tepat. Jawaban benar: ${letters[q.jawaban]}",
                        fontWeight = FontWeight.Bold, color = if (ok) GreenOk else RedBad
                    )
                    Label("Pembahasan")
                    Body(q.bahas)
                }
                PwButton(if (index == soal.size - 1) "Selesai" else "Lanjut →", Modifier.fillMaxWidth()) {
                    if (index == soal.size - 1) {
                        val benar = soal.count { answers[it.id] == it.jawaban }
                        val skor = soal.filter { answers[it.id] == it.jawaban }.sumOf { it.skor }
                        Store.saveHasil(
                            key,
                            Hasil(skor, soal.sumOf { it.skor }, benar, soal.size, soal.filter { answers[it.id] != it.jawaban }.map { it.id })
                        )
                        finished = true
                    } else {
                        index++; selected = null
                    }
                }
            } else {
                Body("Pilih salah satu jawaban.", Color(0xFF546E7A))
            }
        } else {
            val benar = soal.count { answers[it.id] == it.jawaban }
            val skor = soal.filter { answers[it.id] == it.jawaban }.sumOf { it.skor }
            val maks = soal.sumOf { it.skor }
            val persen = benar * 100 / soal.size
            PwCard(container = Blue700) {
                Text("Hasil $judul", color = Color.White, fontWeight = FontWeight.Bold)
                Text("$skor / $maks", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                Text("Benar $benar   •   Salah ${soal.size - benar}   •   $persen%", color = Color.White)
                Text(
                    when {
                        persen >= 80 -> "Luar biasa! Pemahaman Anda sudah sangat baik."
                        persen >= 60 -> "Bagus! Pelajari kembali beberapa bagian agar lebih mantap."
                        else -> "Ayo belajar lagi. Baca kembali materi lalu coba ulangi."
                    }, color = Blue100
                )
            }
            PwCard {
                Heading("Tinjauan Jawaban")
                soal.forEachIndexed { i, s ->
                    val ok = answers[s.id] == s.jawaban
                    Body("${if (ok) "✅" else "❌"} Soal ${i + 1}: ${daftarMateri[s.topik].judul}")
                }
            }
            PwButton("🔁 Ulangi", Modifier.fillMaxWidth()) {
                answers.clear(); index = 0; selected = null; finished = false
            }
            PwButton("🏆 Lihat Evaluasi", Modifier.fillMaxWidth(), color = Blue900) { nav.navigate("evaluasi") }
        }
    }
}

@Composable
fun LatihanScreen(nav: NavController) = QuizRunner(
    nav, soalLatihan, "latihan", "Latihan Soal",
    "15 soal: 5 pemahaman konsep, 5 penerapan rumus, dan 5 analisis. Setiap soal memiliki pilihan A–E, skor, dan pembahasan. Skor: konsep 5, penerapan rumus 7, analisis 8 (total 100)."
)

@Composable
fun KuisScreen(nav: NavController) = QuizRunner(
    nav, soalKuis, "kuis", "Kuis",
    "10 soal pilihan ganda A–E. Setiap soal bernilai 10 poin. Anda akan mendapat umpan balik langsung setelah menjawab."
)

// ============================ EVALUASI ============================
@Composable
fun EvaluasiScreen(nav: NavController) {
    val lat = Store.loadHasil("latihan")
    val kuis = Store.loadHasil("kuis")
    PwScreen("Evaluasi", nav) {
        if (lat == null && kuis == null) {
            PwCard(container = Blue50) {
                Heading("Belum ada hasil")
                Body("Kerjakan Latihan Soal atau Kuis terlebih dahulu. Hasilnya akan muncul di sini.")
            }
            PwButton("Ke Latihan Soal", Modifier.fillMaxWidth()) { nav.navigate("latihan") }
            PwButton("Ke Kuis", Modifier.fillMaxWidth()) { nav.navigate("kuis") }
            return@PwScreen
        }
        val list = listOfNotNull(lat, kuis)
        val skor = list.sumOf { it.skor }
        val maks = list.sumOf { it.skorMaks }
        val benar = list.sumOf { it.benar }
        val total = list.sumOf { it.total }
        val persen = if (total == 0) 0 else benar * 100 / total
        PwCard(container = Blue700) {
            Text("Ringkasan Evaluasi", color = Color.White, fontWeight = FontWeight.Bold)
            Text("$skor / $maks", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
            Text("Benar $benar   •   Salah ${total - benar}   •   $persen%", color = Color.White)
        }
        PwCard {
            Heading("Rincian")
            Body(if (lat != null) "📝 Latihan Soal: skor ${lat.skor}/${lat.skorMaks}, benar ${lat.benar}/${lat.total}" else "📝 Latihan Soal: belum dikerjakan")
            Body(if (kuis != null) "🎯 Kuis: skor ${kuis.skor}/${kuis.skorMaks}, benar ${kuis.benar}/${kuis.total}" else "🎯 Kuis: belum dikerjakan")
        }
        val wrongTopics = mutableListOf<Int>()
        (soalLatihan + soalKuis).forEach { s ->
            val salah = (lat?.salahIds?.contains(s.id) == true) || (kuis?.salahIds?.contains(s.id) == true)
            if (salah && !wrongTopics.contains(s.topik)) wrongTopics.add(s.topik)
        }
        PwCard(container = Blue50) {
            Heading("Rekomendasi Materi yang Perlu Dipelajari Kembali")
            if (wrongTopics.isEmpty()) {
                Body("Semua jawaban benar. Pertahankan! Coba ulangi eksperimen dan LKPD untuk memperdalam pemahaman.")
            } else {
                Body("Berdasarkan soal yang salah, pelajari kembali subbab berikut (ketuk untuk membuka):")
            }
        }
        wrongTopics.sorted().forEach { t ->
            val m = daftarMateri[t]
            Card(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { nav.navigate("materi/$t") },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(m.emoji, fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Text("${m.kode}. ${m.judul}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = Blue900)
                    Text("›", fontSize = 24.sp, color = Blue700)
                }
            }
        }
        PwCard {
            Heading("Kelengkapan Belajar")
            Body("📋 Kolom LKPD terisi: ${Store.countFilled("lkpd")}")
            Body("📊 Baris data eksperimen: ${Store.loadData().size}")
            Body("✍️ Jawaban analisis terisi: ${Store.countFilled("analisis_q")} dari ${pertanyaanAnalisis.size}")
        }
    }
}

// ============================ RANGKUMAN ============================
@Composable
fun RangkumanScreen(nav: NavController) {
    PwScreen("Rangkuman", nav) {
        rangkuman.forEach { (judul, isi) ->
            PwCard {
                Heading(judul)
                isi.forEach { Body("• $it") }
            }
        }
    }
}

// ============================ TENTANG ============================
@Composable
fun TentangScreen(nav: NavController) {
    PwScreen("Tentang", nav) {
        PwCard(container = Blue700) {
            Text("PHYSWAVE", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("Media Pembelajaran Fisika Interaktif", color = Color.White)
            Text("Versi 1.0", color = Blue100, fontSize = 12.sp)
        }
        PwCard {
            Heading("Sasaran dan Materi")
            Body("Untuk siswa SMA Kelas XI / Fase F.")
            Body("Materi: Gelombang dan Penerapannya dalam Kehidupan Sehari-hari.")
        }
        PwCard {
            Heading("Fitur")
            Body("Materi, video pembelajaran, simulasi gelombang, praktikum, LKPD digital, eksperimen sensor HP (accelerometer dan mikrofon), tabel data, grafik, analisis data, latihan soal, kuis, rangkuman, dan evaluasi.")
        }
        PwCard {
            Heading("Offline dan Penyimpanan")
            Body("Materi, simulasi, praktikum, LKPD, eksperimen sensor, latihan, dan kuis dapat dipakai tanpa internet. Hanya video dan thumbnail yang memerlukan internet. Jawaban LKPD, data eksperimen, hasil kuis, dan skor latihan disimpan secara lokal di HP.")
        }
        PwCard {
            Heading("Izin Aplikasi")
            Body("Mikrofon: hanya untuk eksperimen analisis frekuensi bunyi. Rekaman tidak disimpan atau dikirim. Internet: hanya untuk membuka video dan menampilkan thumbnail.")
        }
        PwCard {
            Heading("Teknologi")
            Body("Kotlin • Jetpack Compose • Material 3")
        }
    }
}
