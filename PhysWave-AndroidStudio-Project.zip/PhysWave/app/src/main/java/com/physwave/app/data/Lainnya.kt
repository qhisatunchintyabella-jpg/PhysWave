package com.physwave.app.data

// ====================== VIDEO ======================
// Untuk mengganti URL video secara permanen, ubah nilai "url" di bawah ini,
// atau gunakan tombol "Ubah URL" di dalam aplikasi.
data class VideoItem(
    val id: Int,
    val judul: String,
    val url: String,
    val deskripsi: String,
    val materi: String
)

val daftarVideo = listOf(
    VideoItem(1, "Gelombang Mekanik Fisika Kelas 11 - Part 1: Konsep Gelombang Mekanik",
        "https://www.youtube.com/watch?v=ztJXWeC9-H8",
        "Video pengantar untuk memahami konsep dasar gelombang mekanik sebelum mempelajari besaran dan rumusnya.",
        "A. Pengertian Gelombang • B. Jenis-Jenis Gelombang"),
    VideoItem(2, "Gelombang Transversal dan Longitudinal",
        "https://www.youtube.com/watch?v=ztJXWeC9-H8",
        "Menggunakan video yang sama dengan Video 1. Perhatikan bagian yang menjelaskan gelombang transversal dan gelombang longitudinal serta perbedaan arah getar dan arah rambatnya.",
        "C. Gelombang Transversal • D. Gelombang Longitudinal"),
    VideoItem(3, "Cepat Rambat Gelombang pada Dawai",
        "https://www.youtube.com/watch?v=GI6lie0JEFU",
        "Membahas cepat rambat gelombang dan hubungan antarbesaran gelombang.",
        "I. Cepat Rambat • J. Hubungan f dan T • K. Persamaan v = λf"),
    VideoItem(4, "Karakteristik Gelombang Mekanik: Refleksi, Difraksi dan Interferensi",
        "https://www.youtube.com/watch?v=Ls7olFarLXY",
        "Membahas sifat-sifat gelombang mekanik: refleksi (pemantulan), difraksi, dan interferensi.",
        "L. Pemantulan • N. Difraksi • O. Interferensi"),
    VideoItem(5, "Gejala Gelombang Mekanik: Refleksi dan Refraksi",
        "https://www.youtube.com/watch?v=2cBe4dOF79k",
        "Membahas gejala pemantulan (refleksi) dan pembiasan (refraksi) pada gelombang.",
        "L. Pemantulan • M. Pembiasan"),
    VideoItem(6, "Aplikasi Gelombang Cahaya dalam Kehidupan Sehari-hari",
        "https://www.youtube.com/watch?v=awmmEz5a69Q",
        "Membahas penerapan gelombang dalam kehidupan sehari-hari.",
        "Q. Penerapan Gelombang dalam Kehidupan")
)

// ====================== PRAKTIKUM ======================
object PraktikumData {
    const val judul = "Hubungan Frekuensi, Panjang Gelombang, dan Cepat Rambat Gelombang"

    val tujuan = listOf(
        "Mengukur frekuensi dan panjang gelombang pada tali atau slinky.",
        "Menentukan periode dan cepat rambat gelombang dari data hasil pengukuran.",
        "Menyelidiki hubungan antara frekuensi, panjang gelombang, dan cepat rambat gelombang."
    )
    val dasarTeori = listOf(
        "Frekuensi (f) adalah banyak getaran per sekon: f = n / t. Periode (T) adalah waktu satu getaran: T = 1 / f.",
        "Panjang gelombang (λ) adalah jarak dua bukit berurutan. Cepat rambat gelombang dihitung dengan v = λ × f.",
        "Jika tali dan ketegangannya tidak diubah, cepat rambat gelombang pada tali relatif tetap. Akibatnya, ketika f dinaikkan maka λ mengecil."
    )
    val alatBahan = listOf(
        "HP Android dengan aplikasi PHYSWAVE (untuk stopwatch, merekam video, dan mencatat data)",
        "Tali panjang sekitar 3–4 m atau slinky (pegas mainan)",
        "Penggaris panjang atau meteran",
        "Sumber getaran: tangan siswa yang menggoyangkan ujung tali",
        "Selotip atau kertas kecil sebagai penanda",
        "Lantai datar yang licin dan bebas hambatan"
    )
    val langkah = listOf(
        "Letakkan tali atau slinky di lantai datar. Minta teman memegang salah satu ujung agar tetap diam. Jangan menarik tali terlalu kencang.",
        "Ukur panjang tali dan catat. Jaga panjang dan ketegangan tali tetap sama selama percobaan.",
        "Goyangkan ujung bebas ke kiri-kanan dengan ritme lambat dan teratur hingga terbentuk pola gelombang.",
        "Minta teman menyalakan stopwatch HP selama 10 sekon. Hitung banyak getaran (n) yang Anda lakukan. Hitung f = n / 10.",
        "Minta teman merekam video dari atas. Jeda video saat pola gelombang terlihat jelas, lalu ukur jarak dua puncak berurutan dengan penggaris sebagai skala. Itu panjang gelombang λ (ubah ke meter).",
        "Ulangi langkah 3–5 untuk 5 variasi frekuensi, dari goyangan lambat sampai cepat, tanpa mengubah panjang dan ketegangan tali.",
        "Buka menu Analisis Data → tab Tabel, lalu masukkan nilai f dan λ tiap percobaan. Aplikasi menghitung T dan v secara otomatis.",
        "Buka tab Grafik, tab Analisis, dan tab Kesimpulan untuk menyelesaikan laporan.",
        "Keselamatan: pastikan area sekitar bebas dari orang dan benda, jangan gunakan benda tajam, dan hentikan percobaan jika tali terlalu tegang."
    )
    val kolomTabel = listOf("No.", "Frekuensi (Hz)", "Periode (s)", "Panjang Gelombang (m)", "Cepat Rambat (m/s)")
    val panduanAnalisis = listOf(
        "Bandingkan nilai T untuk f yang berbeda. Apa pola yang terlihat?",
        "Bandingkan λ untuk f yang berbeda. Apakah λ makin kecil saat f makin besar?",
        "Hitung rata-rata v. Apakah nilai v pada tiap percobaan hampir sama?",
        "Sebutkan sumber kesalahan, misalnya ketidaktepatan menghitung getaran, kesalahan membaca skala penggaris, atau ketegangan tali yang berubah."
    )
    val harapanTeori = "Menurut teori, T = 1/f sehingga f yang lebih besar menghasilkan T yang lebih kecil. Jika tali dan ketegangannya sama, v hampir tetap sehingga λ berbanding terbalik dengan f (f naik, λ turun). Bandingkan pernyataan ini dengan data Anda sendiri, lalu tulis kesimpulan berdasarkan data tersebut."
}

// ====================== LKPD ======================
data class Lkpd(
    val no: Int,
    val judul: String,
    val tujuan: String,
    val petunjuk: List<String>,
    val kegiatan: List<String>,
    val tabelJudul: String,
    val headerBaris: String,
    val kolom: List<String>,
    val barisLabel: List<String>,
    val pertanyaan: List<String>
)

val daftarLkpd = listOf(
    Lkpd(1, "Mengenal Karakteristik Gelombang",
        "Membedakan gelombang transversal dan longitudinal serta mengenali bagian-bagian gelombang.",
        listOf("Baca materi A sampai F terlebih dahulu.", "Kerjakan kegiatan secara berurutan.", "Ketik jawaban pada kolom yang tersedia. Jawaban tersimpan otomatis."),
        listOf("Buka menu Simulasi Gelombang. Ubah slider amplitudo dari kecil ke besar dan amati perubahan bentuk gelombang.",
            "Jika tersedia tali atau slinky: goyangkan ujungnya ke samping (transversal) dan dorong-tarik searah panjangnya (longitudinal). Amati arah getar dan arah rambatnya.",
            "Lengkapi tabel pengamatan berikut."),
        "Tabel Pengamatan", "Jenis Gelombang",
        listOf("Arah getar terhadap arah rambat", "Bagian gelombang", "Contoh dalam kehidupan"),
        listOf("Transversal", "Longitudinal"),
        listOf("Jelaskan perbedaan arah getar dan arah rambat pada gelombang transversal dan longitudinal.",
            "Pada simulasi, apa yang terjadi pada tinggi gelombang ketika amplitudo diperbesar?",
            "Apa yang dimaksud dengan satu panjang gelombang pada gelombang transversal?",
            "Mengapa bunyi tidak dapat merambat di ruang hampa?")),
    Lkpd(2, "Hubungan Frekuensi dan Periode",
        "Menentukan hubungan antara frekuensi dan periode dengan T = 1/f.",
        listOf("Baca materi G, H, dan J.", "Gunakan kalkulator HP jika diperlukan.", "Ketik jawaban pada kolom yang tersedia."),
        listOf("Isi kolom frekuensi dengan empat nilai yang Anda pilih (misalnya 1 Hz, 2 Hz, 4 Hz, 5 Hz).",
            "Hitung periode dengan T = 1/f, lalu isi kolom periode.",
            "Buka menu Simulasi Gelombang dan bandingkan hasil perhitungan Anda dengan nilai T pada simulasi."),
        "Tabel Pengamatan", "Data",
        listOf("Frekuensi f (Hz)", "Periode T (s)"),
        listOf("Data 1", "Data 2", "Data 3", "Data 4"),
        listOf("Bagaimana hubungan antara frekuensi dan periode berdasarkan tabel Anda?",
            "Apa yang terjadi pada periode ketika frekuensi diperbesar?",
            "Berapa periode gelombang berfrekuensi 50 Hz? Tuliskan langkah perhitungannya.",
            "Berapa frekuensi gelombang yang periodenya 0,05 s? Tuliskan langkah perhitungannya.")),
    Lkpd(3, "Hubungan Panjang Gelombang, Frekuensi, dan Cepat Rambat",
        "Menggunakan persamaan v = λf untuk menentukan cepat rambat gelombang dan menganalisis hubungan ketiga besaran.",
        listOf("Baca materi F, G, I, dan K.", "Gunakan menu Simulasi Gelombang untuk mengumpulkan data.", "Ketik jawaban pada kolom yang tersedia."),
        listOf("Buka menu Simulasi Gelombang. Atur panjang gelombang dan frekuensi, lalu catat nilai cepat rambat yang tampil.",
            "Lakukan empat kali dengan kombinasi λ dan f yang berbeda.",
            "Periksa apakah hasil simulasi sama dengan hasil hitungan v = λ × f."),
        "Tabel Pengamatan", "Data",
        listOf("λ (m)", "f (Hz)", "v (m/s)"),
        listOf("Data 1", "Data 2", "Data 3", "Data 4"),
        listOf("Jika panjang gelombang tetap dan frekuensi dinaikkan, bagaimana cepat rambat gelombang?",
            "Jika cepat rambat tetap (medium sama) dan frekuensi dinaikkan, bagaimana panjang gelombangnya?",
            "Hitung cepat rambat gelombang jika λ = 1,5 m dan f = 3 Hz.",
            "Bunyi berfrekuensi 500 Hz merambat dengan cepat rambat 340 m/s. Hitung panjang gelombangnya.")),
    Lkpd(4, "Gejala Gelombang dalam Kehidupan Sehari-hari",
        "Mengaitkan gejala pemantulan, pembiasan, difraksi, interferensi, dan polarisasi dengan peristiwa sehari-hari.",
        listOf("Baca materi L sampai Q.", "Amati lingkungan sekitar Anda di rumah dan sekolah.", "Ketik jawaban pada kolom yang tersedia."),
        listOf("Tuliskan satu peristiwa sehari-hari yang Anda temui untuk setiap gejala gelombang pada tabel.",
            "Jelaskan secara singkat mengapa peristiwa tersebut termasuk gejala gelombang yang dimaksud."),
        "Tabel Pengamatan", "Gejala Gelombang",
        listOf("Peristiwa yang ditemui", "Penjelasan singkat"),
        listOf("Pemantulan", "Pembiasan", "Difraksi", "Interferensi", "Polarisasi"),
        listOf("Mengapa suara orang di ruangan lain dapat terdengar melalui pintu yang terbuka walau orangnya tidak terlihat?",
            "Mengapa sedotan tampak patah ketika dimasukkan ke gelas berisi air?",
            "Bagaimana headphone peredam bising (noise-cancelling) mengurangi suara bising?",
            "Mengapa kacamata polaroid dapat mengurangi silau?",
            "Sebutkan satu teknologi yang memanfaatkan pemantulan gelombang dan jelaskan cara kerjanya secara singkat."))
)

// ====================== ANALISIS DATA ======================
val pertanyaanAnalisis = listOf(
    "Bagaimana hubungan frekuensi dengan periode?",
    "Apa yang terjadi pada periode ketika frekuensi meningkat?",
    "Bagaimana hubungan panjang gelombang dengan cepat rambat?",
    "Bagaimana hubungan frekuensi, panjang gelombang, dan cepat rambat?",
    "Apakah hasil eksperimen sesuai dengan teori?",
    "Apa kemungkinan sumber kesalahan pengukuran?"
)

// ====================== RANGKUMAN ======================
val rangkuman = listOf(
    "🌊 Pengertian Gelombang" to listOf(
        "Gelombang adalah getaran yang merambat dan memindahkan energi tanpa memindahkan medium secara permanen."
    ),
    "🧭 Jenis Gelombang" to listOf(
        "Berdasarkan medium: mekanik (butuh medium, mis. bunyi) dan elektromagnetik (tidak butuh medium, mis. cahaya).",
        "Berdasarkan arah getar: transversal (getar ⟂ rambat, terdiri dari bukit dan lembah) dan longitudinal (getar ∥ rambat, terdiri dari rapatan dan renggangan)."
    ),
    "📏 Besaran Gelombang" to listOf(
        "Amplitudo (A): simpangan terbesar dari titik setimbang, satuan m.",
        "Panjang gelombang (λ): jarak dua bukit atau dua rapatan berurutan, satuan m.",
        "Frekuensi (f): banyak getaran per sekon, satuan Hz.",
        "Periode (T): waktu satu getaran, satuan s.",
        "Cepat rambat (v): jarak tempuh gelombang per satuan waktu, satuan m/s."
    ),
    "🧮 Rumus Penting" to listOf(
        "f = n / t",
        "T = t / n",
        "T = 1 / f  dan  f = 1 / T",
        "v = λ × f  atau  v = λ / T",
        "λ = v / f",
        "Pemantulan: θi = θr"
    ),
    "🔬 Gejala Gelombang" to listOf(
        "Pemantulan: gelombang memantul dengan sudut datang = sudut pantul.",
        "Pembiasan: gelombang membelok saat pindah medium karena cepat rambat berubah; frekuensi tetap.",
        "Difraksi: gelombang melentur saat melewati celah atau tepi penghalang.",
        "Interferensi: perpaduan gelombang; konstruktif (menguatkan) dan destruktif (melemahkan).",
        "Polarisasi: pembatasan arah getar; hanya terjadi pada gelombang transversal."
    ),
    "🏥 Penerapan dalam Kehidupan" to listOf(
        "Sonar dan USG (pantulan bunyi), radio, TV, dan sinyal HP (gelombang elektromagnetik).",
        "Oven microwave, rontgen, serat optik, headphone peredam bising, dan kacamata polaroid."
    )
)
