package com.physwave.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.physwave.app.data.Store
import com.physwave.app.ui.AppNav
import com.physwave.app.ui.PhysWaveTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent {
            PhysWaveTheme { AppNav() }
        }
    }
}
