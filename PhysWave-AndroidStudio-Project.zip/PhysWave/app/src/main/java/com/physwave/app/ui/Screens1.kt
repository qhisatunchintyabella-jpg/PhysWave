package com.physwave.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.physwave.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.URL
import kotlin.math.roundToInt
import kotlin.math.sin

// ============================ SPLASH ============================
@Composable
fun SplashScreen(nav: NavController) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        visible = true
        delay(2800)
        nav.navigate("home") { popUpTo("splash") { inclusive = true } }
    }
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = TWO_PI,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Blue900, Blue500))),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            for (k in 0..2) {
                val base = size.height * (0.72f + 0.07f * k)
                val amp = 22f + 8f * k
                val path = Path()
                val n = 80
                for (i in 0..n) {
                    val x = size.width * i / n
                    val y = base + amp * sin(TWO_PI * 1.5f * i / n + phase * (k + 1) * (if (k % 2 == 0) 1f else -1f))
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.lineTo(size.width, size.height)
                path.lineTo(0f, size.height)
                path.close()
                drawPath(path, Color.White.copy(alpha = 0.14f + 0.06f * k))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(900)) + scaleIn(tween(900), initialScale = 0.6f)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Canvas(Modifier.size(120.dp)) {
                        drawCircle(Color.White)
                        val path = Path()
                        val n = 60
                        for (i in 0..n) {
                            val x = size.width * (0.18f + 0.64f * i / n)
                            val y = size.height / 2 - size.height * 0.2f * sin(TWO_PI * i / n + phase)
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(path, Blue700, style = Stroke(width = 9.dp.toPx()))
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("PHYSWAVE", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Media Pembelajaran Fisika Interaktif",
                        color = Color.White.copy(alpha = 0.92f), fontSize = 15.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(4.dp))
                    Text("Gelombang dan Penerapannya", color = Blue100, fontSize = 12.sp)
                }
            }
        }
    }
}

// ============================ BERANDA ============================
private data class MenuItem(val emoji: String, val label: String, val route: String)

@Composable
fun HomeScreen(nav: NavController) {
    val items = listOf(
        MenuItem("📚", "Materi", "materi"),
        MenuItem("🎥", "Video Pembelajaran", "video"),
        MenuItem("🌊", "Simulasi Gelombang", "simulasi"),
        MenuItem("🔬", "Praktikum", "praktikum"),
        MenuItem("📋", "LKPD Digital", "lkpd"),
        MenuItem("📱", "Eksperimen Sensor HP", "sensor"),
        MenuItem("📊", "Analisis Data", "analisis"),
        MenuItem("📝", "Latihan Soal", "latihan"),
        MenuItem("🎯", "Kuis", "kuis"),
        MenuItem("📖", "Rangkuman", "rangkuman"),
        MenuItem("🏆", "Evaluasi", "evaluasi"),
        MenuItem("ℹ️", "Tentang", "tentang")
    )
    Column(
        Modifier
            .fillMaxSize()
            .background(BgColor)
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Blue900, Blue500)), RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .padding(horizontal = 20.dp, vertical = 28.dp)
        ) {
            Text("PHYSWAVE", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Text("Media Pembelajaran Fisika Interaktif", color = Color.White.copy(alpha = 0.92f), fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text("Gelombang dan Penerapannya dalam Kehidupan Sehari-hari • Kelas XI / Fase F", color = Blue100, fontSize = 12.sp)
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { nav.navigate("tujuan") },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Blue50)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🎯", fontSize = 28.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Tujuan Pembelajaran", fontWeight = FontWeight.Bold, color = Blue900)
                        Text("Lihat apa yang akan Anda capai", fontSize = 12.sp, color = TextDark)
                    }
                    Text("›", fontSize = 26.sp, color = Blue700)
                }
            }
            items.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { m ->
                        Card(
                            Modifier
                                .weight(1f)
                                .height(112.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .clickable { nav.navigate(m.route) },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(3.dp)
                        ) {
                            Column(
                                Modifier
                                    .fillMaxSize()
                                    .padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    Modifier
                                        .size(48.dp)
                                        .background(Blue50, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) { Text(m.emoji, fontSize = 26.sp) }
                                Spacer(Modifier.height(8.dp))
                                Text(m.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Blue900, textAlign = TextAlign.Center, lineHeight = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================ TUJUAN ============================
@Composable
fun TujuanScreen(nav: NavController) {
    PwScreen("Tujuan Pembelajaran", nav) {
        PwCard(container = Blue50) {
            Body("Setelah menggunakan aplikasi, siswa diharapkan mampu:")
        }
        tujuanPembelajaran.forEachIndexed { i, t ->
            PwCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(30.dp).background(Blue700, CircleShape), contentAlignment = Alignment.Center) {
                        Text("${i + 1}", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Body(t)
                }
            }
        }
    }
}

// ============================ MATERI ============================
@Composable
fun MateriListScreen(nav: NavController) {
    PwScreen("Materi Pembelajaran", nav) {
        PwCard(container = Blue50) {
            Body("Gelombang dan Penerapannya dalam Kehidupan Sehari-hari. Pilih subbab untuk mulai belajar.")
        }
        daftarMateri.forEachIndexed { i, m ->
            Card(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { nav.navigate("materi/$i") },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Blue700, CircleShape), contentAlignment = Alignment.Center) {
                        Text(m.kode, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(m.judul, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = Blue900)
                    Text(m.emoji, fontSize = 22.sp)
                }
            }
        }
    }
}

@Composable
fun MateriDetailScreen(nav: NavController, index: Int) {
    val i = index.coerceIn(0, daftarMateri.size - 1)
    val m = daftarMateri[i]
    PwScreen("${m.kode}. ${m.judul}", nav) {
        Illustration(m.ilustrasi)
        PwCard {
            Label("Pengertian"); Body(m.pengertian)
            Spacer(Modifier.height(4.dp))
            Label("Penjelasan"); Body(m.penjelasan)
        }
        if (m.rumus.isNotEmpty()) {
            PwCard(container = Blue50) {
                Label("Rumus")
                m.rumus.forEach { Text(it, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Blue900) }
                if (m.simbol.isNotEmpty()) { Label("Simbol"); Body(m.simbol) }
                if (m.satuan.isNotEmpty()) { Label("Satuan"); Body(m.satuan) }
            }
        }
        PwCard {
            Label("Contoh"); Body(m.contoh)
            Spacer(Modifier.height(4.dp))
            Label("Contoh dalam kehidupan sehari-hari"); Body(m.sehari)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PwButton("← Sebelumnya", Modifier.weight(1f), enabled = i > 0) {
                nav.navigate("materi/${i - 1}") { popUpTo("materi") { inclusive = false } }
            }
            PwButton("Selanjutnya →", Modifier.weight(1f), enabled = i < daftarMateri.size - 1) {
                nav.navigate("materi/${i + 1}") { popUpTo("materi") { inclusive = false } }
            }
        }
    }
}

// ============================ VIDEO ============================
private val thumbCache = HashMap<String, android.graphics.Bitmap>()

fun youtubeId(url: String): String? {
    val u = url.trim()
    val v = Regex("[?&]v=([A-Za-z0-9_-]{6,})").find(u)?.groupValues?.get(1)
    if (v != null) return v
    return Regex("youtu\\.be/([A-Za-z0-9_-]{6,})").find(u)?.groupValues?.get(1)
}

@Composable
fun VideoThumb(url: String) {
    val id = youtubeId(url)
    val bmp by produceState<android.graphics.Bitmap?>(initialValue = id?.let { thumbCache[it] }, id) {
        if (id != null && value == null) {
            value = withContext(Dispatchers.IO) {
                try {
                    val conn = URL("https://img.youtube.com/vi/$id/hqdefault.jpg").openConnection()
                    conn.connectTimeout = 6000; conn.readTimeout = 6000
                    conn.getInputStream().use { BitmapFactory.decodeStream(it) }
                } catch (e: Exception) { null }
            }
            value?.let { thumbCache[id] = it }
        }
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(Blue900, Blue500))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("Thumbnail memerlukan internet", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp))
        }
        Box(Modifier.size(54.dp).background(Color.Black.copy(alpha = 0.55f), CircleShape), contentAlignment = Alignment.Center) {
            Text("▶", color = Color.White, fontSize = 24.sp)
        }
    }
}

@Composable
fun VideoScreen(nav: NavController) {
    val ctx = LocalContext.current
    val urls = remember {
        mutableStateMapOf<Int, String>().apply {
            daftarVideo.forEach { put(it.id, Store.getText("video_url_${it.id}", it.url)) }
        }
    }
    var editing by remember { mutableStateOf<VideoItem?>(null) }
    var err by remember { mutableStateOf<String?>(null) }

    PwScreen("Video Pembelajaran", nav) {
        PwCard(container = Blue50) {
            Body("Video diputar melalui YouTube (aplikasi YouTube atau browser) dan memerlukan internet. Jika ada video yang berubah atau tidak tersedia, tekan 'Ubah URL' untuk menggantinya.")
        }
        daftarVideo.forEach { v ->
            val url = urls[v.id] ?: v.url
            PwCard {
                VideoThumb(url)
                Text("Video ${v.id}", fontSize = 12.sp, color = Blue500, fontWeight = FontWeight.Bold)
                Text(v.judul, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Blue900)
                Body(v.deskripsi)
                Body("Materi terkait: ${v.materi}", Blue700)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PwButton("▶ Tonton", Modifier.weight(1f)) {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        } catch (e: ActivityNotFoundException) {
                            err = "Tidak ada aplikasi untuk membuka tautan. Pasang browser atau YouTube."
                        } catch (e: Exception) {
                            err = "Tautan video tidak dapat dibuka. Periksa URL."
                        }
                    }
                    OutlinedButton(onClick = { editing = v }, shape = RoundedCornerShape(12.dp)) { Text("Ubah URL") }
                }
            }
        }
    }

    err?.let {
        AlertDialog(onDismissRequest = { err = null }, confirmButton = { TextButton(onClick = { err = null }) { Text("OK") } }, title = { Text("Video") }, text = { Text(it) })
    }
    editing?.let { v ->
        var text by remember(v.id) { mutableStateOf(urls[v.id] ?: v.url) }
        var bad by remember(v.id) { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Ubah URL Video ${v.id}") },
            text = {
                Column {
                    OutlinedTextField(text, { text = it; bad = false }, label = { Text("URL YouTube") }, isError = bad)
                    if (bad) Text("URL harus diawali http:// atau https://", color = RedBad, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = text.trim()
                    if (t.startsWith("http://") || t.startsWith("https://")) {
                        urls[v.id] = t; Store.putText("video_url_${v.id}", t); editing = null
                    } else bad = true
                }) { Text("Simpan") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { urls[v.id] = v.url; Store.putText("video_url_${v.id}", v.url); editing = null }) { Text("Kembalikan") }
                    TextButton(onClick = { editing = null }) { Text("Batal") }
                }
            }
        )
    }
}

// ============================ SIMULASI ============================
@Composable
private fun ParamSlider(label: String, value: Float, unit: String, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(label, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = Blue900)
            Text("${fmt(value.toDouble(), 1)} $unit", fontWeight = FontWeight.Bold, color = Blue700)
        }
        Slider(value = value, onValueChange = { onChange((it * 10).roundToInt() / 10f) }, valueRange = range)
    }
}

@Composable
fun SimulasiScreen(nav: NavController) {
    var amp by remember { mutableFloatStateOf(5f) }
    var freq by remember { mutableFloatStateOf(1f) }
    var lam by remember { mutableFloatStateOf(2f) }
    var playing by remember { mutableStateOf(true) }
    var time by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(playing) {
        if (playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                time += (now - last) / 1_000_000_000f
                last = now
            }
        }
    }

    val T = 1.0 / freq
    val v = lam.toDouble() * freq

    PwScreen("Simulasi Gelombang", nav) {
        PwCard {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(Blue50, RoundedCornerShape(10.dp))
            ) {
                val w = size.width; val h = size.height; val cy = h / 2
                val ampPx = amp / 10f * (h / 2 - 14.dp.toPx())
                for (i in 0..10) {
                    val x = w * i / 10
                    drawLine(Blue100, Offset(x, 0f), Offset(x, h), 1f)
                }
                drawLine(Color.Gray, Offset(0f, cy), Offset(w, cy), 2f)
                val path = Path()
                val n = 240
                for (i in 0..n) {
                    val xm = 10f * i / n
                    val y = cy - ampPx * sin(TWO_PI * (xm / lam - freq * time))
                    val x = w * i / n
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, Blue500, style = Stroke(width = 4.dp.toPx()))
                val py = cy - ampPx * sin(TWO_PI * (5f / lam - freq * time))
                drawCircle(Color(0xFFE53935), 7.dp.toPx(), Offset(w / 2, py))
            }
            Body("Lebar tampilan = 10 m. Titik merah adalah partikel medium di x = 5 m: hanya bergetar naik-turun, tidak ikut merambat.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PwButton(if (playing) "⏸ Jeda" else "▶ Putar", Modifier.weight(1f)) { playing = !playing }
                OutlinedButton(onClick = { time = 0f }, shape = RoundedCornerShape(12.dp)) { Text("Ulang waktu") }
            }
        }
        PwCard {
            Heading("Atur Parameter")
            ParamSlider("Amplitudo (A)", amp, "cm", 1f..10f) { amp = it }
            ParamSlider("Frekuensi (f)", freq, "Hz", 0.5f..5f) { freq = it }
            ParamSlider("Panjang gelombang (λ)", lam, "m", 0.5f..5f) { lam = it }
        }
        PwCard(container = Blue50) {
            Heading("Hasil Perhitungan Otomatis")
            Body("Amplitudo  A = ${fmt(amp.toDouble(), 1)} cm")
            Body("Frekuensi  f = ${fmt(freq.toDouble(), 1)} Hz")
            Body("Periode  T = 1/f = 1/${fmt(freq.toDouble(), 1)} = ${fmt(T, 3)} s")
            Body("Panjang gelombang  λ = ${fmt(lam.toDouble(), 1)} m")
            Body("Cepat rambat  v = λ × f = ${fmt(lam.toDouble(), 1)} × ${fmt(freq.toDouble(), 1)} = ${fmt(v, 3)} m/s")
        }
        PwCard {
            Heading("Coba Ini")
            Body("1. Perbesar amplitudo. Apa yang berubah pada bentuk gelombang? Apakah v ikut berubah?")
            Body("2. Naikkan frekuensi, biarkan λ tetap. Bagaimana v dan T berubah?")
            Body("3. Kecilkan λ, biarkan f tetap. Bagaimana nilai v?")
        }
    }
}
